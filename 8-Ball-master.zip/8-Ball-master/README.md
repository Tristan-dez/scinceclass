# 8-Ball
8-ball pool game with computer-controlled opponent, base design from miniclip.com (http://www.miniclip.com/games/8-ball-pool-multiplayer)
